package com.example.bgccheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BgcCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(BgcCheckApplication.class, args);
	}

}
