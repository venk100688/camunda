package com.example.bgccheck.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController  
public class BgcCheckController   
{  
  
	@Autowired
	ObjectMapper mapper;
	
	@GetMapping("/check")
    public ResponseEntity<String> verifyCustomer() throws JsonProcessingException {
        
		Map<String,Object> responseBody= new HashMap<String,Object>();
		
    	responseBody.put("Demographic_Check","Valid");
    	responseBody.put("Criminal_Check","Valid");
    	responseBody.put("Credit_Score",750);
    	
    	return ResponseEntity.ok()
    			.body(mapper.writeValueAsString(responseBody));
    }   
}  
