package com.example.workflow.beans;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
	List<Customer> findByFirstNameAndMobile(String firstName, String mobile);

	List<Customer> findByCustId(String custId);
}