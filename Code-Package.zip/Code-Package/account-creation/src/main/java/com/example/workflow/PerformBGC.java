package com.example.workflow;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;


@Component
public class PerformBGC {
	
	private static Logger logger = LoggerFactory.getLogger(PerformBGC.class);

    // This would be of course injected and depends on the environment. Hard coded for now
	/*
	 * public static String BGC_URL = "http://localhost:8080/check";
	 * 
	 * @Autowired private RestTemplate restTemplate;
	 * 
	 * @ZeebeWorker(type = "bgcCheck") public ResponseEntity<String> bgcCheck(final
	 * ActivatedJob job) throws IOException {
	 * logger.info("Verifying customer via REST [" + job + "]");
	 * 
	 * HttpEntity<String> req = new HttpEntity<String>("request");
	 * 
	 * System.out.println("printing:" +restTemplate.exchange(BGC_URL,HttpMethod.GET,
	 * req,String.class));
	 * 
	 * return restTemplate.exchange(BGC_URL,HttpMethod.GET, req,String.class); }
	 */
}
