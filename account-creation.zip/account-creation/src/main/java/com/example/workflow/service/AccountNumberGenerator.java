package com.example.workflow.service;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class AccountNumberGenerator {
	
	Random random = new Random();
	
	  static long current = System.currentTimeMillis();
	  
	  	  
	  static public synchronized long getAcctNum()
	  {
		  return current++;
	  }
	  
	  public synchronized int getCustId()
	  {
		  return random.nextInt(Integer.MAX_VALUE);
	  }
	
}
