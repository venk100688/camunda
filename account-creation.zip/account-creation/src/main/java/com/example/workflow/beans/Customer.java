package com.example.workflow.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "customers")
public class Customer {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "custId")
	private String custId;
	
	@Column(name = "acctNum")
	private String acctNum;
	
	@Column(name = "firstName")
    private String firstName;
	
	@Column(name = "lastName")
    private String lastName;
    
	@Column(name = "address")
    private String address;
	
	@Column(name = "mobile")
    private String mobile;
	
	@Column(name = "mail")
    private String mail;
	
	@Column(name = "existingCust")
    private String existingCust;
	
	private String requestType;

	public Customer(String custId,String acctNum,String address,
			String existingCust, String firstName, String lastName, String mail, String mobile) {
		super();
		this.custId = custId;
		this.acctNum = acctNum;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.mobile = mobile;
		this.mail = mail;
		this.existingCust = existingCust;
	}
	
	
}
